/** Automatically generated file. DO NOT MODIFY */
package com.gag.tarea1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}